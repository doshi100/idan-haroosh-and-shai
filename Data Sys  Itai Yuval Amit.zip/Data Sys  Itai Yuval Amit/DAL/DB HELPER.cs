﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.OleDb;
using System.Threading.Tasks;

namespace DAL
{

    public class DB_HELPER
    {

        public const int WRITEDATA_ERROR = -1;

        private OleDbConnection conn;
        private string provider;
        private string source;
        private bool connOpen;


        public DB_HELPER(string provider, string source)
        {
            this.provider = provider;
            this.source = source;


        }

 
        public string BuildConnString()
        {
            return String.Format(@"Provider={0};Data Source={1};", provider, source);

        }


        public void CloseConnection()
        {
            if (conn == null) return;
            conn.Close();
            connOpen = false;
        }

        public DataTable GetDataTable(string sql)
        {
            OleDbDataReader reader = ReadData(sql);
            DataTable output = null;

            if (reader != null)
            {
                output = new DataTable();
                output.Load(reader);
                CloseConnection();
            }
            return output;
        }


        public int InsertWithAutoNumKey(string sql)
        {
            try
            {
                if (!OpenConnection()) return WRITEDATA_ERROR;
                OleDbCommand cmd = new OleDbCommand(sql, conn);

                OleDbDataReader reader = cmd.ExecuteReader();

                if (reader != null && reader.RecordsAffected == 1)
                {
                    cmd = new OleDbCommand(@"SELECT @@Identity", conn);
                    reader = cmd.ExecuteReader();
                    int newID = WRITEDATA_ERROR;
                    while (reader.Read())
                    {
                        newID = (int)reader[0];
                    }
                    return newID;
                }
                else return WRITEDATA_ERROR;
            }
            catch
            {
                return WRITEDATA_ERROR;
            }
        }



        public int WriteData(string sql)
        {
            try
            {
                if (!OpenConnection()) return WRITEDATA_ERROR;
                OleDbCommand cmd = new OleDbCommand(sql, conn);

                OleDbDataReader reader = cmd.ExecuteReader();
                CloseConnection();
                return reader.RecordsAffected;
            }
            catch
            {
                return WRITEDATA_ERROR;
            }
        }


        public OleDbDataReader ReadData(string sql)
        {

            OpenConnection();

            OleDbCommand cmd = new OleDbCommand(sql, conn);
            return cmd.ExecuteReader();
        }

        public bool OpenConnection()
        {
            if (conn == null) conn = new OleDbConnection(BuildConnString());
            try
            {
                if (conn.State != ConnectionState.Open)
                {
                    conn.Open();
                    connOpen = true;
                }

            }
            catch
            {
                return false;
            }
            return true;
        }

    }
}