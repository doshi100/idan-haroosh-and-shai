﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.OleDb;
using BL;

namespace Data_Sys___Itai_Yuval_Amit
{
    public class SeaCusInvUI
    {
        // display matched Customer Invitation ON DEMAND 
        static public void show(List<Customer> customerL)
        {
            Console.WriteLine("Do you want to see one of the customer invitations?, Enter YES or NO");
            string option = Console.ReadLine().ToLower();
            Console.Clear();
            if (option == "yes")
            {
                Console.WriteLine("Please enter your requested customer ID");
                int id = int.Parse(Console.ReadLine());
                Console.Clear();
                List<Invitation> rows = Invitation.IdSearch(id);
                for(int i=0;i<customerL.Count;i++)
                {
                    if(customerL[i].Customerid == id)
                    {
                        customerL[i].SetInv(rows);
                    }
                }
                TableView.Printer(rows);
            }
        }
    }
}
