﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;
using System.Data;
using System.Data.OleDb;

namespace BL
{
    public class Customer
    {
        // properties
        public int Customerid { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Address { get; set; }
        public List<Invitation> invitations { get; set; }
        // Constructor

        public Customer(string FirstName, string LastName, string Address)
        {
            this.FirstName = FirstName;
            this.LastName = LastName;
            this.Address = Address;
            this.invitations = null;
        }
        public int AddCustomerToDB()
        {
            return DAL.CustomersDB.AddCustomer(FirstName, LastName, Address);
        }
        static public List<Customer> LNameSearch(string LName)
        {
            List<Customer> CustomerRows = new List<Customer>();
            DataTable table = CustomersDB.SearchCustomer(LName);
            for (int i = 0; i < table.Rows.Count; i++)
            {
                DataRow row = table.Rows[i];
                int CustomerID = (int)row["CustomerID"];
                string LastName = row["LName"].ToString();
                string FirstName = row["FName"].ToString();
                string Address = row["Address"].ToString();
                Customer customer = new Customer(FirstName, LastName, Address);
                customer.Customerid = CustomerID;
                CustomerRows.Add(customer);
            }
            return CustomerRows;
        }

        public void SetInv(List<Invitation> list)
        {
            invitations = list;
        }
    }
}