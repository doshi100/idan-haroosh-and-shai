﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.OleDb;

namespace DAL
{
    public class CustomersDB
    {
        const string provider = @"Microsoft.ACE.OLEDB.12.0";
        const string source = @"..\..\Database1.accdb";
        public static DB_HELPER D1 = new DB_HELPER(provider, source);
        // add a customer to the table [Customers]
        public static int AddCustomer(string FName, string LName, string Address)
        {
            string sql = $"INSERT INTO Customers (FName, LName, Address) VALUES ('{FName}', '{LName}', '{Address}')";
            return D1.InsertWithAutoNumKey(sql);
        }
        public static DataTable SearchCustomer(string LName)
        {
            string sql = $@"SELECT * FROM Customers WHERE LName = '{LName}'";
            DataTable table = D1.GetDataTable(sql);
            return table;
        }
    }
}
