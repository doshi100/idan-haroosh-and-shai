﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BL;

namespace Data_Sys___Itai_Yuval_Amit
{
    public class MainMenu
    {
        public static void Drawing(int num, string[] arr)
        {
            Console.Clear();
            for (int i = 0; i < arr.Length; i++)
            {
                if (num == i)
                {
                    Console.BackgroundColor = ConsoleColor.Gray;
                    Console.ForegroundColor = ConsoleColor.DarkCyan;
                }
                Console.WriteLine("");
                Console.WriteLine("");
                Console.WriteLine("");
                Console.SetCursorPosition((Console.WindowWidth - arr[i].Length) / 2, Console.CursorTop);
                Console.WriteLine(arr[i]);
                Console.ResetColor();
                Console.WriteLine("");

            }
        }

        public static bool Show()
        {
            //Console.BackgroundColor = ConsoleColor.White;
            //Console.Clear();
            Console.ForegroundColor = ConsoleColor.DarkCyan;
            Console.WriteLine("");
            Console.WriteLine("");


            string s = "Welcome To The Club-Med User Interface";
            Console.SetCursorPosition((Console.WindowWidth - s.Length) / 2, Console.CursorTop);
            Console.WriteLine(s);
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("");

            string s1 = "Press Enter To Continue";
            Console.SetCursorPosition((Console.WindowWidth - s1.Length) / 2, Console.CursorTop);
            Console.WriteLine(s1);
            Console.ReadKey();

            int num = 0;
            string[] arr = { "Add Customer", "Search Customer By Last Name",  "QUIT" };
            Console.CursorVisible = false;
            Drawing(num, arr);

            while (true)
            {
                ConsoleKey StrikeAgain = Console.ReadKey(true).Key;
                switch (StrikeAgain)
                {
                    case (ConsoleKey)38:
                        num += -1 + arr.Length;
                        num = num % arr.Length;
                        Drawing(num, arr);
                        break;
                    case (ConsoleKey)40:
                        num++;
                        num = num % arr.Length;
                        Drawing(num, arr);
                        break;
                    case (ConsoleKey)13:
                        switch (num)
                        {
                            //Add Customer Show
                            case 0:
                                AddCustomer.Show();
                                break;
                                //Search Customer By Last Name
                            case 1:
                                SearchCustomer.show();
                                break;

                                //New Invitation
                            case 2:

                                SearchCustomer.show();
                                break;

                            case 3:


                            //Exit Program
                            case 4:
                                Environment.Exit(0);
                                break;


                        }
                        return false;

                }
            }



        }

    }
}
