﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;

namespace BL
{
    public class Village
    {
        public int VillageID { get; set; }
        public string VillageName { get; set;}
        public string Address { get; set; }
        public string Activities { get; set;}
        public string  CountryISC { get; set; }
        public int TypeCounter { get; set; }
        private List<Room> Rooms = new List<Room>();
        public List<Room> rooms
        {
            get
            {
                return Rooms;
            }
        }
        public void AddRoomToList(Room room)
        {
            Rooms.Add(room);
        }
        
        public Village(string VillageName, string Address, string activities, string CountryISC, int RoomTypeCounter)
        {
            this.VillageName = VillageName;
            this.Address = Address;
            this.Activities = activities;
            this.CountryISC = CountryISC;
           
        }
        public int AddVillageToDB()
        {
            return VillageDB.AddVillage(VillageName, Address, Activities, CountryISC, TypeCounter);
        }
        
        
    }
}
