﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.OleDb;



namespace DAL
{
    public static class InvitationDB
    {
        const string provider = @"Microsoft.ACE.OLEDB.12.0";
        const string source = @"..\..\Database1.accdb";
        public static DB_HELPER D1 = new DB_HELPER(provider, source);




        // adds a new invitation to the table Invitation
        public static int NewInvitation(int CustomerID, DateTime StartDate, DateTime EndDate)
        {
            string NewInvitationSql = $@"INSERT INTO Invitations 
                    (FName, LName, StartDate, EndDate) 
                    VALUES ('{StartDate}', '{EndDate}', '{CustomerID}')";
            int InvitationID = D1.InsertWithAutoNumKey(NewInvitationSql);

            return InvitationID;

        }

        // adds a new invitation to the table Rooms Invitation
        public static void AddRoomInvitationHelper(string RoomSearchSql, int InvitationID)
        {
            OleDbDataReader RoomReader = D1.ReadData(RoomSearchSql);
            int RoomID = 0;
            while (RoomReader.Read())
            {
                RoomID = (int)RoomReader.GetValue(0);
            }
            AddRoomInvitation(InvitationID, RoomID);
        }
        private static void AddRoomInvitation(int InvitationID, int RoomID)
        {
            string RoomInvSql = $@"INSERT INTO [Rooms Invitations] 
                                ([Invitation ID], [Room ID]) 
                                VALUES ({InvitationID}, {RoomID});";
            D1.InsertWithAutoNumKey(RoomInvSql);
        }

        public static DataTable SearchCusInvitation(int id)
        {
            string sql = $@"SELECT * FROM Invitations WHERE CustomerID = {id}";
            DataTable table = D1.GetDataTable(sql);
            return table;
        }
    }
}

