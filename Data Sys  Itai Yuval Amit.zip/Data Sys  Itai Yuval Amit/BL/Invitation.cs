﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;
using System.Data;
using System.Data.OleDb;

namespace BL
{
    public class Invitation
    {
        // properties
        public int InvitationID { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public int CustomerID { get; set; }
        public List<Room> rooms { get; set; }
        //constructor
        public Invitation(DateTime StartDate, DateTime EndDate, int CustomerID)
        {
            this.StartDate = StartDate;
            this.EndDate = EndDate;
            this.CustomerID = CustomerID;
            this.rooms = null;
        }
        //public void NewRoomInInv(int RoomID)
        //{
        //    Room room = new Room(Price, TypeID, VillageID, RoomTypeCNT);
        //    rooms.Add(room);
        //}
        public int AddInvitationToDB()
        {
            return InvitationDB.NewInvitation(CustomerID, StartDate, EndDate);
        }

        static public List<Invitation> IdSearch(int id)
        {
            List<Invitation> CustomerInv = new List<Invitation>();
            DataTable table = InvitationDB.SearchCusInvitation(id);
            for (int i = 0; i < table.Rows.Count; i++)
            {
                DataRow row = table.Rows[i];
                int InvitationID = (int)row["Invitation ID"];
                DateTime startDate = Convert.ToDateTime(row["StartDate"]);
                DateTime EndDate = Convert.ToDateTime(row["EndDate"]);
                int CustomerID = (int)row["CustomerID"];
                Invitation Invite = new Invitation(startDate, EndDate, CustomerID);
                Invite.InvitationID = InvitationID;
                CustomerInv.Add(Invite);
            }
            return CustomerInv;
        }

        public void SetRooms(List<Room> list)
        {
            rooms = list;
        }

    }
}
