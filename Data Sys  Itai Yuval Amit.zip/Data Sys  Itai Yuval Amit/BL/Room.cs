﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;
using System.Data;
using System.Data.OleDb;

namespace BL
{
    public class Room
    {
        public int RoomID {get; set;}

        // Empty room constructor 
        public Room(int id)
        {
            this.RoomID = id;
        }

        static public List<Room> IdRoomSearch(int id)
        {
            List<Room> CustomerRoom = new List<Room>();
            DataTable table = RoomDB.SearchInvitationRoom(id);
            for (int i = 0; i < table.Rows.Count; i++)
            {
                DataRow row = table.Rows[i];
                int RoomID = (int)row["Room ID"];
                Room Invite = new Room(RoomID);
                CustomerRoom.Add(Invite);
            }
            return CustomerRoom;
        }

    }
}
