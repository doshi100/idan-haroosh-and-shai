﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.OleDb;

namespace DAL
{
    public class RoomDB
    {
        const string provider = @"Microsoft.ACE.OLEDB.12.0";
        const string source = @"..\..\Database1.accdb";
        public static DB_HELPER D1 = new DB_HELPER(provider, source);

        public static int AddRoom(double Price, int VillageID, int TypeID, int RoomsTypeCNT)
        {
            string SQL = "INSERT INTO Rooms ([Price], [Village ID], [TypeID], [RoomsTypeCNT]) VALUES " + "(" + Price + ", " + VillageID + ", " + TypeID + ", " + RoomsTypeCNT + ")";
            return D1.InsertWithAutoNumKey(SQL);
        }
        public static double GetRoomPrice(int RoomID)
        {
            string sql = $"SELECT Price FROM Rooms WHERE [Room ID] = {RoomID}";
            DataTable table = D1.GetDataTable(sql);
            return 5;
        }

        public static DataTable SearchInvitationRoom(int InvitationID)
        {
            string sql = $@"SELECT * FROM [Rooms Invitations] WHERE [invitation ID] = {InvitationID}";
            DataTable table = D1.GetDataTable(sql);
            return table;
        }


    }
}
