﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;
using System.Data;
using BL;

namespace Data_Sys___Itai_Yuval_Amit
{
    class TableView
    { 
        public static void Printer<T>(List<T> list)
        {
            Type t1 = list[0].GetType();
            PropertyInfo[] propInfos = t1.GetProperties(BindingFlags.Public | BindingFlags.Instance);
            string spaces = "            ";
            Console.WriteLine($"Property Name{spaces}Value");
            foreach(object x in list)
            {
                foreach (PropertyInfo propInfo in propInfos)
                {
                    bool readable = propInfo.CanRead;
                    bool writable = propInfo.CanWrite;

                    Console.Write(propInfo.Name);
                    
                    if (readable)
                    {
                        Console.WriteLine($"{spaces}" + propInfo.GetValue(x));
                    }
                }
                Console.WriteLine();
            }
        }
        static void Show()
        {
        }
    }
}
