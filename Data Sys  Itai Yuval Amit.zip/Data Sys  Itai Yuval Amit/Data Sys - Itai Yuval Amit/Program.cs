﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data_Sys___Itai_Yuval_Amit
{
    class Program
    {
        static void Main(string[] args)
        {
            MainMenu.Show();
            Console.ReadKey();
        }
    }
}
