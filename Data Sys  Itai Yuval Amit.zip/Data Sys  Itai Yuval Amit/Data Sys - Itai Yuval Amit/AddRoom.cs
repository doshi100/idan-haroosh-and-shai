﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BL;


namespace Data_Sys___Itai_Yuval_Amit
{
    static class AddRoom
    {
        //public static Room AddRoomUI(int NewVillageID)
        //{
        //    Console.WriteLine("Please Enter The Room Type 1-Regular, 2-Family, 3-Suite");
        //    int TypeID = int.Parse(Console.ReadLine());
        //    Console.WriteLine("Please Enter Price For The Room");
        //    double Price = double.Parse(Console.ReadLine());
        //    Console.WriteLine("How many rooms like this would you like to add?");
        //    int RoomsTypeCNT = int.Parse(Console.ReadLine());
        //    return /*new Room(Price, TypeID, NewVillageID, RoomsTypeCNT)*/;
        //}
    }
}
