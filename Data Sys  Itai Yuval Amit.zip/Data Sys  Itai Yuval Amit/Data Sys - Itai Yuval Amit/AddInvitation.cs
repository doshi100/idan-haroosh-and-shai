﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BL;

namespace Data_Sys___Itai_Yuval_Amit
{
    class AddInvitation
    {
        public void Show()
        {
            Console.Clear();
            Console.WriteLine("Please Enter Your Customer ID");
            int CustomerID = int.Parse(Console.ReadLine());
            Console.Clear();
            Console.WriteLine("Please Enter The First Date Of Your Invitation");
            DateTime InvStartDate = DateTime.Parse(Console.ReadLine());
            Console.Clear();
            Console.WriteLine("Please Enter The Last Date Of Your Invitation");
            DateTime InvEndDate = DateTime.Parse(Console.ReadLine());
            Console.Clear();
            Invitation invitation = new Invitation(InvStartDate, InvEndDate, CustomerID);
            int InvitationID = invitation.AddInvitationToDB();



            Console.WriteLine("Please enter your chosen village id");

            //Console.WriteLine(ClubMedDBAcess.VillagesPresentation());

            //foreach (DataRow dataRow in .Rows)
            //{
            //    foreach (var item in dataRow.ItemArray)
            //    {
            //        Console.WriteLine(item);
            //    }
            //}
            int VillageIdInvitation = int.Parse(Console.ReadLine());

            Console.WriteLine("How Many Rooms Would You Like To Invite?");
            int NumRooms = int.Parse(Console.ReadLine());



            //for (int i = 0; i < NumRooms; i++)
            //{
            //    Console.WriteLine("Please Enter The Room Type For The {0} Room You Would Like To Order 1-Regular, 2-Family, 3-Suite", i + 1);
            //    int TypeID = int.Parse(Console.ReadLine());


            //    string RoomSearchSql = $@"SELECT r.[Room ID]
            //                            FROM Rooms r
            //                            WHERE r.TypeID={TypeID} AND r.[Village ID]={VillageIdInvitation}";
            //    Invitation invitation = new Invitation(InvStartDate, InvEndDate, CustomerID);
            //    Invitation.AddRoomInvitationHelper(RoomSearchSql, InvitationID);
            //    invitation.AddInvitationToDB();

            //}
        }
    }
}
