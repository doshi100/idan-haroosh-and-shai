﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BL;

namespace Data_Sys___Itai_Yuval_Amit
{
    static class AddCustomer
    {
        public static void Show()
        {
            Console.Clear();
            Console.WriteLine("Enter Your First Name");
            string FirstName = Console.ReadLine();
            Console.Clear();
            Console.WriteLine("Enter Your Last Name");
            string LastName = Console.ReadLine();
            Console.Clear();
            Console.WriteLine("Enter Your Address");
            string Address = Console.ReadLine();
            Console.Clear();
            Customer customer = new Customer(FirstName, LastName, Address);
            Console.WriteLine("Thank You For Applying To Our DataBase!");
            customer.AddCustomerToDB();
            Console.WriteLine("To Go Back To Mian Menu Press Any Key");
            MainMenu.Show();
        }
        
    }
}
