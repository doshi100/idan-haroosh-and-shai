﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BL;

namespace Data_Sys___Itai_Yuval_Amit
{
    class AddVillage
    {
        public AddVillage()
        {
            //Console.Clear();
            //Console.CursorVisible = true;
            //Console.WriteLine("Enter The Name Of The Village");
            //string VillageName = Console.ReadLine();
            //Console.Clear();
            //Console.WriteLine("Enter The Address Of The Village");
            //string Address = Console.ReadLine();
            //Console.Clear();
            //Console.WriteLine("Enter The Activities Of The Village");
            //string Activities = Console.ReadLine();
            //Console.Clear();
            //Console.WriteLine("Enter The Country Code Of The Village IL-ISRAEL, JP-JAPAN, NP-NAPAL, PE-PERU");
            //string Country = Console.ReadLine();
            //Console.Clear();
            //Console.WriteLine("How Many Types Of Rooms Do You Want");
            //int TypeCounter = int.Parse(Console.ReadLine());
            //Console.Clear();
            //Village village = new Village(VillageName, Address, Activities, Country, TypeCounter);
            //int NewVillageID = village.AddVillageToDB();

            //for (int i = 0; i < TypeCounter; i++)
            //{

            //    Room room = AddRoom.AddRoomUI(NewVillageID);
            //    village.AddRoomToList(room);
            //}
        }
    }
}
