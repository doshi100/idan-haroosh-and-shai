﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BL;
using System.Data;


namespace Data_Sys___Itai_Yuval_Amit
{
    class SearchCustomer
    {
        // display matched customers who have the same Last Name 
        public static void show()
        {
            Console.Clear();
            Console.WriteLine("Enter Your Last Name");
            string LastName = Console.ReadLine();
            Console.Clear();
            List<Customer> rows = Customer.LNameSearch(LastName);
            TableView.Printer(rows);
            int i = ShowInv(rows);
            // invitation rows
            List<Invitation> rows2 = Invitation.IdSearch(i);
            ShowRoomInv(rows2);
            Console.WriteLine("To Go Back To Main Menu Press Any Key");
            MainMenu.Show();
        }

        private static int ShowInv(List<Customer> customerL)
        {
            int id = 0;
            Console.WriteLine("Do you want to see one of the customer invitations?, Enter YES or NO");
            string option = Console.ReadLine().ToLower();
            if (option == "yes")
            {
                Console.WriteLine("Please enter your requested customer ID");
                id = int.Parse(Console.ReadLine());
                Console.Clear();
                List<Invitation> rows = Invitation.IdSearch(id);
                for (int i = 0; i < customerL.Count; i++)
                {
                    if (customerL[i].Customerid == id)
                    {
                        customerL[i].SetInv(rows);
                    }
                }
                TableView.Printer(rows);
            }
            return id;
        }

        private static void ShowRoomInv(List<Invitation> customerL)
        {
            Console.WriteLine("Do you want to see one of the invitation's rooms?, Enter YES or NO");
            string option = Console.ReadLine().ToLower();
            if (option == "yes")
            {
                Console.WriteLine("Please enter your requested Invitation ID");
                int id = int.Parse(Console.ReadLine());
                Console.Clear();
                List<Room> rows = Room.IdRoomSearch(id);
                for (int i = 0; i < customerL.Count; i++)
                {
                    if (customerL[i].InvitationID == id)
                    {
                        customerL[i].SetRooms(rows);
                    }
                }
                TableView.Printer(rows);
            }
        }
    }
}
