﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.OleDb;

namespace DAL
{
    public class VillageDB
    {
        const string provider = @"Microsoft.ACE.OLEDB.12.0";
        const string source = @"..\..\Database1.accdb";
        public static DB_HELPER D1 = new DB_HELPER(provider, source);
        public static int AddVillage(string VillageName, string Address, string Activities, string Country, int TypeCounter)
        {
            string SQL = "INSERT INTO Villages ([Village Name], [Address], [Activities], [CountryISO]) VALUES " + "(" + "'" + VillageName + "', " + "'" + Address + "', " + "'" + Activities + "', " + "'" + Country + "'" + ")";

            int NewVillageID = D1.InsertWithAutoNumKey(SQL);

            return NewVillageID;
        }

        public static string[] SearchVillage(string CountryISO, int RoomTypeID, DateTime WantedStartDate, DateTime WantedEndDate)
        {
            string SQL = $@"SELECT v.[Village Name], a.[Start Date], a.[End Date] 
                           FROM Villages v, [Active Period] a, Rooms r 
                           WHERE v.[Village ID] = a.[Village ID] 
                           AND v.[Village ID] = r.[Village ID] 
                           AND a.[Village ID] = r.[Village ID] 
                           AND v.CountryISO = '{CountryISO}' 
                           AND r.TypeID = {RoomTypeID}";

            DataTable results = new DataTable();
            results.Load(D1.ReadData(SQL));

            string[] RelevantVillages = FindVillagesByDates(results, WantedStartDate, WantedEndDate);

            return RelevantVillages;
        }
        private static string[] FindVillagesByDates(DataTable Villages, DateTime WantedStartDate, DateTime WantedEndDate)
        {
            const string START_DATE = "Start Date";
            const string END_DATE = "End Date";
            const string VILLAGE_NAME = "Village Name";

            string[] VillagesInRange = new string[Villages.Rows.Count];
            DateTime CurrStartDate;
            DateTime CurrEndDate;
            int filteredVillages = 0;

            foreach (DataRow CurrRow in Villages.Rows)
            {
                CurrStartDate = DateTime.Parse(CurrRow[START_DATE].ToString());
                CurrEndDate = DateTime.Parse(CurrRow[END_DATE].ToString());

                // If the wanted dates are in the active dates range of the village
                if (WantedStartDate >= CurrStartDate && WantedEndDate <= CurrEndDate)
                {
                    VillagesInRange[filteredVillages] = CurrRow[VILLAGE_NAME].ToString();
                    filteredVillages++;
                }
            }

            return VillagesInRange;
        }
        public static DataTable VillagesPresentation()
        {
            string sql = @"SELECT v.[Village ID], v.[Village Name]
                        FROM Villages AS v";
            DataTable Villages = D1.GetDataTable(sql);
            return Villages;
        }
    }
}
